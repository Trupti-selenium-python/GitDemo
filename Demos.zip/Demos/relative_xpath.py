"""
Relative Xpath starts from the middle of HTML DOM structure. It starts with double forward slash (//)
Relative Xpath is always preferred as it is not a complete path from the root element.

"""

from selenium import webdriver
driver=webdriver.Chrome("C:\\Users\\Sakhamuri\\Desktop\\chromedriver\\chromedriver.exe")
driver.get("https://www.amazon.com/")
driver.maximize_window()
driver.find_element_by_xpath("//a[@id='nav-logo-sprites']").click() #basic Xpath
driver.find_element_by_xpath("//*[@id='nav-xshop']/a[3]").click()  #relative Xpath