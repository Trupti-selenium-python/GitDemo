"""
Basic synatx

//tagname[@attribute='value']

"""
# Expertise in writing XPATH syntax
from selenium import webdriver
driver=webdriver.Chrome("C:\\Users\\Sakhamuri\\Desktop\\chromedriver\\chromedriver.exe")
driver.get("https://www.facebook.com/")
driver.maximize_window()
driver.find_element_by_xpath("//input[@class='inputtext _55r1 _6luy']").send_keys("123")