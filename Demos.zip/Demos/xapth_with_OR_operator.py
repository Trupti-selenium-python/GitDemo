from selenium import webdriver
driver=webdriver.Chrome("C:\\Users\\Sakhamuri\\Desktop\\chromedriver\\chromedriver.exe")
driver.get("https://www.amazon.com/")
driver.find_element_by_xpath("//*[@type='text' or @id='twotabsearchtextbox']").send_keys("123")
